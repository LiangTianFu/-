//$(function() {
//	
//	// 数量减
//	$('.sub').click(function() {
//		var t = $(this).parent().find('.quantity');
//		t.text(parseInt(t.text()) - 1);
//		if (t.text() <= 1) {
//			t.text(1);
//		}
//		TotalPrice();
//	});
//	
//	// 数量加
//	$('.add').click(function() {
//		var t = $(this).parent().find('.quantity');
//		t.text(parseInt(t.text()) + 1);
//		if (t.text() <= 1) {
//			t.text(1);
//		}
//		TotalPrice();
//	});
//	
//	//点击商品按钮
//	$(".goods-checkbox").click(function() {
//	
//  	var goods = $(this).closest(".c-shop").find(".goods-checkbox"); //获取本店铺的所有商品
//  
//  	var goodsC = $(this).closest(".c-shop").find(".goods-checkbox:checked"); //获取本店铺所有被选中的商品
//  
//  	var Shops = $(this).closest(".c-shop").find(".shop-checkbox"); //获取本店铺的全选按钮
//  
//	    if (goods.length == goodsC.length) { //如果选中的商品等于所有商品
//	      
//	      	Shops.prop('checked', true); //店铺全选按钮被选中''
//	      
//	      	if ($(".shop-checkbox").length == $(".shop-checkbox:checked").length) { //如果店铺被选中的数量等于所有店铺的数量
//	        
//	        	$(".allchecked").prop('checked', true); //全选按钮被选中
//	        
//	        	TotalPrice();
//	        	
//	      } else {
//	        
//	        $(".allchecked").prop('checked', false); //else全选按钮不被选中
//	        
//	        TotalPrice();
//	      }
//	    
//	    } else { //如果选中的商品不等于所有商品
//	      
//	      	Shops.prop('checked', false); //店铺全选按钮不被选中
//	      
//	      	$(".allchecked").prop('checked', false); //全选按钮也不被选中
//	      	// 计算
//	      	TotalPrice();
//	      
//	    }
//	});
//	
//	
//	//点击店铺按钮
//	$('.shop-checkbox').click(function() {
//		
//		if ($(this).prop("checked") == true) {//如果店铺按钮被选中
//			
//			$(this).parents(".c-shop").find(".goods-checkbox").prop('checked', true); //店铺内的所有商品按钮也被选中
//		      	
//		    $(".allchecked").prop('checked', true); //全选按钮被选中
//		      	
//		      	if ($(".shop-checkbox").length == $(".shop-checkbox:checked").length) { //如果店铺被选中的数量等于所有店铺的数量
//		        	
//		        	$(".allchecked").prop('checked', true); //全选按钮被选中
//		        	
//		        	TotalPrice();
//		      	
//		      	} else {
//		        	
//		        	$(".allchecked").prop('checked', false); //else全选按钮不被选中
//		        	
//		        	TotalPrice();
//		      	}
//		      	
//		    } else { //如果店铺按钮不被选中
//		      	
//		      	$(this).parents(".c-shop").find(".goods-checkbox").prop('checked', false); //店铺内的所有商品也不被全选
//		      	
//		      	$(".allchecked").prop('checked', false); //全选按钮也不被选中
//		      	
//		      	TotalPrice();
//		}	
//	});
//	
//	
//	//点击全选按钮
////	$(".allchecked").click(function() {
////
////	    if ($(this).prop("checked", true) ) { //如果全选按钮被选中
////	      	
////	      	$(".c-checkbox").prop('checked', true); //所有按钮都被选中
////	      	
////	      	TotalPrice();
////	      	
////	    } else if ($(this).prop("checked", false) ) {
////	    	
////	    	$(".c-checkbox").prop('checked', false); //else所有按钮不全选''
////	    	
////	    	TotalPrice();
////	    	
////	    } else {//如果全选按钮不被选中
////	      	
////	      	$(".c-checkbox").prop('checked', false); //else所有按钮不全选''
////	      	
////	      	TotalPrice();
////	    }
////	    	$(".shop-checkbox").change(); //执行店铺全选的操作
////	});
//
//	$(".allchecked").click(function() {
//  
//  if ($(this).prop("checked", true) ){ //如果全选按钮被选中
//    	
//    	$(".c-checkbox").prop('checked', true); //所有按钮都被选中
//    	
//    	TotalPrice();
//  } else {
//  	
//
//    	
//    	$(".c-checkbox").prop('checked', false); //else所有按钮不全选
//
//    	$(this).prop("checked") != $(this).prop("checked");
//    	
//    	TotalPrice();
//  }
//  	$(".shop-checkbox").change(); //执行店铺全选的操作
//});
//	
//	
//	
//	
//	//计算总价
//	function TotalPrice() {
//		
//		var allprice = 0; //总价
//		
//		$('.c-shop').each(function () {//循环每个店铺
//			
//			var oprice = 0; //店铺总价
//			
//			var total_count = 0;//商品件数
//			
//			$(this).find(".goods-checkbox").each(function() { //循环店铺里面的商品
//				
//		        if ($(this).is(":checked")) { //如果该商品被选中
//		        	
//		          	var num = parseInt($(this).parents(".shop-info").find(".quantity").text()); //得到商品的数量
//		          	
//		          	var price = parseFloat($(this).parents(".shop-info").find(".price").text()); //得到商品的单价
//		          	
//		          	var total = price * num; //计算单个商品的总价
//		          	
//		          	oprice += total; //计算该店铺的总价
//		          	
//		          	total_count += num;//计算该店铺的商品数量
//
//		        }
//		        	
//		        	$(".ShopTotal").text(oprice.toFixed(2)); //显示被选中商品的店铺总价
//		        	$('.totalNum').text(total_count);
//		      
//				});
//				
//					
//					
//		      		var oneprice = parseFloat($(".ShopTotal").text()); //得到每个店铺的总价
//		      		
//		      		allprice += oneprice; //计算所有店铺的总价
//		      		
//		})
//		
//		$(".ShopTotal").text(allprice.toFixed(2)); //输出全部总价
//		
//	
//  
//	}  
//	
//	//结算
//	
//	
//	
//});




//
$(function() {
	
$.ajax({
	type:"post",
	url:"http://192.168.0.8/hyapi/cart/get",
	dataType:'json',
	success:function(res) {

		var jsonres = res.data;
//		var len = jsonres.length;
		
		console.log(res);
		
//		var resulthtml = '<div class="cart-box">'
//		
//			for (var i = 0; i < len; i++) {
//				resulthtml +=
//				//店名
//				'<div class="b-dot">'+
//					'<div class="dot-box">'+
//						'<input type="checkbox" class="input-reset c-checkbox shop-checkbox" style="transform-origin: 0px 0px 0px; opacity: 1; transform: scale(1, 1);">'+
//						'<label for="checkboxFourinput" class="changecolor">'+'</label>'+
//					'</div>'+
//					'<a href="#" class="c-sn">'+'<label>'+ jsonres[i].base_info.shop_name +'</label>'+'</a>'+
//					'<div class="c-lq c-right-box">'+'<span>'+ '领券' +'</span>'+'</div>'
//				'</div>'
//				//满减
//				
//		
//					
//				
//				
//				
//			}
//		resulthtml += '</div>';
//		$('#shops-app').html(resulthtml);
		
		
		
	}
	
	
	
	
});
	
	
});





