
$(function(){
	
	//导航收藏选项卡
    $('.tabs li a').click(function(){
    	$(this).css('color','#EC4D81');
    	$('.tabs li a').not(this).css('color','#333');
        $(this).addClass('tab-list').siblings();
        $('.tabs li a').not(this).removeClass('tab-list');
        
    });
    //我的足迹
    $('#my-slot').click(function() {
    	$('.my-slot').css('display','block');
    	$('.my-goods').css('display','none');
    	$('.shop-collect-finsh').css('display','none');
    	$('.old-goosd').css('display','none');
    	$('.shop-collect').css('display','none');
    })
    //商品收藏
    $('.old-goosd').css('display','block');
    $('#my-goods').click(function() {
//  	$('.my-goods').css('display','block');
		$('.old-goosd').css('display','block');
    	$('.my-slot').css('display','none');
    	$('.shop-collect').css('display','none');
    	$('.shop-collect-finsh').css('display','none');
    })
    //店铺收藏
    $('#shop-collect').click(function() {
    	$('.shop-collect').css('display','block');
    	$('.shop-collect-finsh').css('display','none');
    	$('.old-goosd').css('display','none');
    	$('.my-slot').css('display','none');
    })
    
    
    
    
    //全选
    
    
    
    
    
    
    

    //取消关注
    $(document).on('swipe','#item .mui-media',function(){
		$('.unfollow').hide()
	 	$('.unfollow', this).show();
	 	//商品向左移
	 	$('.slide-left', this).animate({left: '-5rem'});
	 	$('.slide-left').css({left: '0'});
	})
   	
	$(document).on('tap','.unfollow',function(){
		$(this).parent('.mui-media').remove(); 	
	})


	//
    
});

