//轮播图
$(function() {
	setTimeout(function(){
    var gallery = mui('.mui-slider');
    gallery.slider({
         interval:3000//自动轮播周期，若为0则不自动播放，默认为0；
    });
},300)
})


//商品主图轮播
function getQueryVariable(variable){
   	var query = window.location.search.substring(1);
   	var vars = query.split("&");
   	for (var i=0;i<vars.length;i++) {
        var pair = vars[i].split("=");
        if(pair[0] == variable){return pair[1];}
   }
   return(false);
}
 

var goods_id = getQueryVariable('goods_id');

var common_param = {
	goods_id:goods_id
}
$.ajax({
	type:"get",
	url:"http://192.168.0.8/hyapi/goods/getgoodsdetail",
	data:{
		common_param:JSON.stringify(common_param),
	},
	success:function(res){
		
		var jsonres = res.data.img_list;
		
		var len = jsonres.length;
		
		//图片
		var jsonhtml = ('<div class="mui-slider-group mui-slider-loop">');
		//0
		jsonhtml += ('<div class="mui-slider-item mui-slider-item-duplicate">'+'<a href="#">'+'<img src="'+ configurl +'/'+jsonres[0].pic_cover_small+'" />'+'</a>'+'</div>');		
		
		for (var i = 0; i < len; i++) {

			jsonhtml += ('<div class="mui-slider-item">'+'<a href="#">'+'<img src="'+ configurl +'/'+jsonres[i].pic_cover_small+'" />'+'</a>'+'</div>');		
		
		}
			
		//len-1
		jsonhtml += ('<div class="mui-slider-item mui-slider-item-duplicate">'+'<a href="#">'+'<img src="'+ configurl +'/'+jsonres[len-1].pic_cover_small+'" />'+'</a>'+'</div>');			
			 
		jsonhtml += "</div>";
		
		//圆点
		var dothtml = ('<div class="mui-slider-indicator">');
		
		for (var j = 0; j < len; j++) {
				
			if (j == 0){
				dothtml += ('<div class="mui-indicator mui-active"></div>');
			}else{
				dothtml += ('<div class="mui-indicator"></div>');
				
			}
				
		}
		dothtml += '</div>';
		
		document.getElementById("lb-box").innerHTML = jsonhtml + dothtml;

	}	
	 
});

