$(function() {
	//搜索框 焦点事件
	$('#search').focus(function() {
		$('.shousuo').hide();
	});

	$('#search').blur(function() {
		$('.shousuo').show();
	});
});



//导航
$(function() {

	$.ajax({
		type: "get",
		url: "../api/getgoodscategorylistbyparentid.json",
		//url: "http://192.168.0.8/hyapi/goodscategory/getgoodscategorylistbyparentid",
		dataType: "json",
		success: function(res) {

			var HeadNav = $("#head-nav")
			var HeadItemHtml = ''
			var HideItem = HeadNav.find('#opover .mui-table-view')
			var HideItemHtml = ''
			for (var i = 0; i < res.data.length; i++) {

				if (res.data[i].is_visible) {
					console.log(res.data[i].is_visible);
					if (i == 0) {
						HeadItemHtml += '<a class="mui-control-item mui-active" href="#item2mobile">' + res.data[i].category_name + '</a>'
					} else {
						HeadItemHtml += '<a class="mui-control-item" href="#item2mobile">' + res.data[i].category_name + '</a>'
					}

				} else {

					HideItemHtml += '<li class="mui-table-view-cell"><a href="#">' + res.data[i].category_name + '</a></li>'
				}

			}
			HeadNav.find('#sliderSegmentedControl').append(HeadItemHtml)
			HeadNav.find('.mui-table-view').append(HideItemHtml)
			//var jsonhtml = res.data;

			// var len = jsonhtml.length

			// var tmp = '<div id="sliderSegmentedControl" class="mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">'

			// for (var i = 0; i < len; i++) {

			// 	if (i == 0) {
			// 		tmp +=
			// 			('<a class="mui-control-item mui-active" href="#item1mobile"> ' + jsonhtml[i].category_name + '</a>');
			// 	} else {
			// 		tmp +=
			// 			('<a class="mui-control-item " href="#item1mobile"> ' + jsonhtml[i].category_name + '</a>');
			// 	}
			// }

			// tmp += '<a class="mui-control-item" href="#">' + '<span class="mui-icon mui-icon-arrowdown">' + '</span></a>';

			// tmp += "</div>";
			// document.getElementById("head-nav").innerHTML = tmp;
		}
	});

});

//轮播
$.ajax({
	type: "get",
	url: "../api/getadlist.json",
	//	url:"http://192.168.0.8/hyapi/platform/getadslist?common_param={\"ap_id\":1105}",
	dataType: "json",
	success: function(res) {

		var slideBox = $("#lb-box")
		var slideGroupHTML = '<div class="mui-slider-group">'
		var slideCrileHtml = '<div class="mui-slider-indicator">'
		for (var i = 0; i < res.data.adv_list.length; i++) {

			slideGroupHTML += `<div class="mui-slider-item"><a href="${res.data.adv_list[i].adv_url}"><img src="${res.data.adv_list[i].adv_image}" /></a></div>`

			// slideGroupHTML += ' <div class="mui-slider-item"><a href="' + res.data.adv_list[i].adv_url + '"><img src="' + res.data.adv_list[i].adv_image + '" / > < /a></div > '

			if (i == 0) {
				slideCrileHtml += '<div class="mui-indicator mui-active"></div>'
			} else {


				slideCrileHtml += '<div class="mui-indicator"></div>'
			}

		}
		slideGroupHTML += '</div>'
		slideCrileHtml += '</div>'
		slideBox.append(slideGroupHTML, slideCrileHtml)

		//轮播图
		setTimeout(function() {
			mui(slideBox).slider({
				interval: 3000 //自动轮播周期，若为0则不自动播放，默认为0；
			});
		}, 300)
	}



});


//限时抢购
// 倒计时

function p(s) {
	return s < 10 ? '0' + s : s;
}

function showTime() {
	var nowtime = new Date()
	var endtime = new Date("2018,5,21,23:26:00")
	var Countdown = parseInt((endtime.getTime() - nowtime.getTime()) / 1000); //获得倒计时,取整秒  //时间差
	var d = parseInt(Countdown / (24 * 60 * 60)); //取整天
	var h = parseInt(Countdown / (60 * 60) % 24); //%24  除去天数剩余的小时
	var m = parseInt(Countdown / 60 % 60); //%60  除去小时剩余的分钟
	// var s = parseInt(Countdown % 60); //%60  除去分钟剩余的秒数
	var s = Countdown % 60; //%60  除去分钟剩余的秒数   

	// document.getElementById('countdown').innerHTML =  d + '天' + h + '小时' + m + '分' + s + '秒';
	if (d != 0) {
		document.getElementById('countdown').innerHTML = '<span>' + p(d) + '</span>天' + '<span>' + p(h) + ' </span>时' + '<span>' + p(m) + '</span>分' + '<span>' + p(s) + '</span>秒';

	} else {
		document.getElementById('countdown').innerHTML = '<span>' + p(h) + ' </span>时' + '<span>' + p(m) + '</span>分' + '<span>' + p(s) + '</span>秒';

	}

	if (Countdown <= 0) {
		document.getElementById('countdown').innerHTML = '抢购结束';
		clearTimeout(showTime);
	}
	setTimeout(showTime, 1000);
}

window.onload = function() {
	showTime();
}



// 	var t =980000000000;//秒数
// 	function showtime(){

// //		var d = parseInt(t/3600/24);
// //		if(d<10){
// //			d="0"+d;	
// //		}
// 		var h = parseInt((t%(3600*24))/3600);
// 		if(h<10){
// 			h="0"+h;	
// 		}
// 		var m = parseInt((t%(3600*24))%3600/60);
// 		if(m<10){
// 			m="0"+m;	
// 		}
// 		var s = parseInt((t%(3600*24))%60);
// 		if(s<10){
// 			s="0"+s;	
// 		}
// //		var a=(d=="00")?"":'<span>'+d+' </span>天 ';
// 		var b=(h=="00")?"":'<span>'+ h+' </span> 时 ';
// 		var c=(m=="00")?"":'<span>'+m+' </span> 分 ';
// 		var d=(s=="00")?"":'<span>'+s+' </span> 秒';
// 		$('.countdown').html(b+c+d);
// 		t = t -1;
// 	}
// 	showtime();
// 	setInterval("showtime()",1000);  

$(function() {
	$.ajax({
		type: "post",
		url: "http://192.168.0.8/hyapi/goods/getgoodslist?common_param=",
		dataType: "json",
		success: function(res) {

			var jsonres1 = res.data.data;
			var len = jsonres1.length;

			var jsonnew = [];

			for (var g = 0; g < len; g++) {
				var arr;
				if (g % 3 == 0) {
					jsonnew.push(arr);
					arr = [];
				}

				arr.push(JSON.parse(JSON.stringify(jsonres1[g])));
				if (g == (len - 1)) {
					jsonnew.push(arr);
				}
			}

			var lennew = jsonnew.length;

			//					console.log(jsonnew)

			var texthtml1 = '<div class="bd">'

			var str = "";

			for (var g = 1; g < lennew; g++) {

				var lihtml = '<ul class="ulhtml">'

				//						 console.log(jsonnew[g])

				for (var u = 0; u < jsonnew[g].length; u++) {

					lihtml +=

						('<li>' +
							'<a href="">' +
							'<img src="' + configurl + '/' + jsonnew[g][u].pic_cover_mid + '"/>' +
							'<span>' + jsonnew[g][u].goods_name + '</span>' +
							'<div class="sh-price">' +
							'<p>' + '￥' + '<b>' + jsonnew[g][u].price + '</b>' + '</p>' +
							'<del>' + '￥' + '<i>' + jsonnew[g][u].price + '</i>' + '</del>' +
							'</div>' +
							'</a>' +
							'</li>');

				}

				lihtml += '</ul>';

				texthtml1 += lihtml;

				str += lihtml;

			}

			texthtml1 += '</div>';

			$("#picScroll .bd").html(str);

			TouchSlide({
				slideCell: "#picScroll",
				titCell: ".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
				autoPage: true, //自动分页
				pnLoop: "false", // 前后按钮不循环
				switchLoad: "_src" //切换加载，真实图片路径为"_src" 
			});

		}

	});

});


//精选推荐
$(function() {
	$.ajax({
		type: "get",
		url: "../api/getgoodslist.json",
		//url: "http://192.168.0.8/hyapi/goods/getgoodslist?common_param=",
		dataType: "json",
		success: function(res) {

			var jsonres3 = res.data.data;

			var goodsId = res.data.data.goods_id;

			var len = jsonres3.length;

			var texthtml3 = '<div class="mui-card group sift goods-list">';

			for (var i = 0; i < len; i++) {

				texthtml3 +=

					'<div class="img-text pro-img" data-id="' + jsonres3[i].goods_id + '">' +
					'<div class="mui-card-content hot">' + '<a>' + '<img src="' + jsonres3[i].pic_cover_small + '"/>' + '</a>' + '</div>' +
					// '<div class="mui-card-content hot">' + '<a>' + '<img src="' + configurl + '/' + jsonres3[i].pic_cover_small + '"/>' + '</a>' + '</div>' +
					'<div class="mui-card-footer hot">' +
					'<span class="si-text">' + jsonres3[i].goods_name + '</span>' +
					'<div class="i-price">' +
					'<span>' + '￥' + '<b>' + jsonres3[i].price + '</b>' + '<del>' + '￥' + '<span class="if">' + jsonres3[i].promotion_price + '</span>' + '</del>' + '</span>' +
					'<em class="bnsd-size" style="color:#8c8c8c;">' + '已售' + '<i>' + jsonres3[i].sales + '</i>' + '件' + '</em>' +
					'</div>' +
					'</div>' +
					'</div>'

				ad = jsonres3[i].goods_id;
				//				console.log(ad)

			}

			texthtml3 += '</div>';
			document.getElementById("sift-box").innerHTML = texthtml3;

			//点击每个商品跳转详情页
			$("#sift-box").on("tap", '.pro-img', function(e) {
				e.preventDefault();

				var gid = $(this).attr('data-id');

				window.location.href = 'detail.html?goods_id=' + gid;

			});
		}

	});



});


//推荐头条
$(function() {
	$.ajax({
		type: "post",
		url: "http://192.168.0.8/hyapi/article/getarticlelist?common_param=",
		dataType: "json",
		success: function(res) {
			var jsonres4 = res.data.data;
			var len = jsonres4.length;

			var texthtml4 = '<ul class="rowup">';

			for (var i = 0; i < len; i++) {

				texthtml4 +=
					'<li class="tuijian">' +
					'<a href="#">' +
					'<p>' + '<span>' + '</span>' + '<i>' + jsonres4[i].name + '</i>' + '</p>' +
					'<p>' + jsonres4[i].title + '</p>' +
					'<p>' + '|' + '&nbsp;' + '&nbsp;' + '&nbsp;' + '&nbsp;' + '更多' + '</p>' +
					'</a>' +
					'</li>'

			}

			texthtml4 += '</ul>';
			document.getElementById("headline").innerHTML = texthtml4;
		}

	});
});

//拼团
$(function() {
	$.ajax({
		type: "post",
		url: "http://192.168.0.8/hyapi/goods/getgoodslist?common_param=",
		dataType: "json",
		success: function(res) {
			var jsonres2 = res.data.data;
			var len = jsonres2.length;

			//			var picimg = res.data.data.img_list;

			//			console.log(jsonres2[0].img_list)

			var texthtml2 = '<div class="group-box">'

			for (var i = 0; i < len; i++) {

				texthtml2 +=
					'<div class="mui-card group" data-id=' + jsonres2[i].goods_id + '>' +
					'<div class="mui-card-footer rsh">' +
					'<div class="mui-card-content">' + '<a href="#">' + '<img src="' + configurl + '/' + jsonres2[i].img_list[jsonres2[i].img_list.length - 1].pic_cover_big + '"/>' + '</a>' + '</div>' +
					'<div class="mui-card-footer">' +
					'<div class="i-price">' +
					'<span>' + '￥' + '<b>' + jsonres2[i].price + '</b>' + '</span>' +
					'</div>' +
					'<p>' + '<a href="#">' + '马上拼团' + '</a>' + '</p>' +
					'<span class="text">' + '【买就送】' + jsonres2[i].goods_name + '</span>' +
					'</div>' +
					'</div>' +
					'</div>'
				//				console.log(jsonres2[i].img_list[jsonres2[i].img_list.length - 1].pic_cover_big);
			}
			texthtml2 += '</div>';
			document.getElementById("group-box").innerHTML = texthtml2;
		}

	});

});



//广告
$(function() {
	$.ajax({
		type: "post",
		url: "http://192.168.0.8/hyapi/platform/getadslist?common_param={\"ap_id\":1162}",
		dataType: "json",
		success: function(res) {
			var resimg = res.data.adv_list;
			//			console.log(resimg)
			var imghtml = '<a href="#">';

			imghtml += '<img src="' + configurl + '/' + resimg[0].adv_image + '" />'

			imghtml += '</a>';
			document.getElementById("banner-img").innerHTML = imghtml;

		}

	});
})