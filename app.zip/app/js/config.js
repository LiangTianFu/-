var configurl = "http://192.168.0.8"
;